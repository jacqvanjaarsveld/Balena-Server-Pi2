## A Simple Server with Python Flask

This is a Flask server project that is designed to work on a Raspberry Pi Zero W.

This project simply displays `"BRNJAM019 and VJRJAC003 think that Balena Rocks!"` on port `:80` of any connected balena device, in this case our Raspberry Pi Zero W.

## Authors: James Burness (BNRJAM019), Jacq van Jaarsveld (VJRJAC003)